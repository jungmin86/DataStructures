//
//  main.cpp
//  LAB11_#1
//
//  Created by Jungmin Kim on 2023/05/23.
//

#include <iostream>
#include "PQType.h"
//C.Big-O notation
//ReheapUp과 ReheapDown은 모두 O(logN)을 가진다.

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
