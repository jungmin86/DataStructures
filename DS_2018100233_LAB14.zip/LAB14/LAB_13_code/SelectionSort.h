#include "Student.h"

void SelectionSort(Student ary[], int numElems);