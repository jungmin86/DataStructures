#include "HashTable.h"


HashTable::HashTable(int max_num)
{
    emptyItem.InitValue(0, "empty", 0.0);

    /* code */    
}


int HashTable::Hash(Student item) const
{
    /* code */   
    
    return index;
}

void HashTable::InsertItem(Student item)
{

    /* code */   
}

void HashTable::DeleteItem(Student item)
{
    /* code */   
}


void HashTable::Print() {

    
    cout << "--------------------" << endl;
    cout << "[]:index, ():student" << endl;
    
    /* code */
    
    cout << "--------------------" << endl;
     
}