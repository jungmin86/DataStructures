#include "HashTable.h"


HashTable::HashTable(int max_num)
{
    emptyItem.InitValue(0, "empty", 0.0);
    max_items = max_num;
    table = new NodeType;
    for (int i = 0; i < max_num; i++) {
        table[i].stu = emptyItem;
    }
}



int HashTable::Hash(Student item) const
{
    int index, char_sum, _id;
    char _name[30];
    float _gpa;
    item.getValue(_id, _name, _gpa);
    char_sum = 0;
    for (int i = 0; i < sizeof(_name)/sizeof(char); i++) {
        if (_name[i] == '\0') break;
        char_sum += toascii(_name[i]);
    }
    index = (char_sum + _id) % max_items;
    return index;
}

void HashTable::RetrieveItem(Student& item, bool& found) {
    NodeType* location;
    int startLoc;
    bool moreToSearch = true;
    
    startLoc = Hash(item);
    location = &table[startLoc];
    do
    {
        if (location->stu == item || location->stu == emptyItem)
            moreToSearch = false;
        else
            location = location->next;
    } while (location != NULL && moreToSearch);
    found = (location->stu == item);
    if(found) {}
        item = location->stu;
}


void HashTable::InsertItem(Student item)
{
    NodeType* location;
    NodeType* newNode;

    bool exist;

    RetrieveItem(item, exist);
    if (exist == true) {
        return;
    }
    bool moreToSearch;

    location = &table[Hash(item)];
    moreToSearch = (location->next != NULL);

    if (&table[Hash(item)] == NULL) {
        location->stu = item;
        location->next = NULL;
    }
    else {
        while (moreToSearch)
        {
            location = location->next;
            moreToSearch = (location->next != NULL);
          }
        }

        newNode = new NodeType;
        newNode->stu = item;
        location->next = newNode;
        newNode->next = NULL;
}

void HashTable::DeleteItem(Student item)
{
    bool exist;

    RetrieveItem(item, exist);
    if (exist == false) {
        return;
    }
    
}


void HashTable::Print() {

    
    cout << "--------------------" << endl;
    cout << "[]:index, ():student" << endl;
    Student item;
    bool found = true;
    RetrieveItem(item, found);
    for(int i = 0; i < max_items; i++) {
        
        if (item == emptyItem && !found) {
            cout << "[" << i << "]: empty" << endl;
        }
        else {
            int index = Hash(item);
            NodeType* location = &table[index];
            cout << "[" << i << "]: ";
            item.Print(cout);
            while (location->next != NULL) {
                location = location->next;
                cout << "->";
                location->stu.Print(cout);
            }
            cout << endl;
        }
    }
    
    cout << "--------------------" << endl;
     
}

