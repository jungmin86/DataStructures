#include "Student.h"

void QuickSort(Student values[], int first, int last);