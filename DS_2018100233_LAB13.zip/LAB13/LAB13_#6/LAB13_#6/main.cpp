//
//  main.cpp
//  LAB13_#6
//
//  Created by Jungmin Kim on 2023/06/08.
//

#include <iostream>
#include "Student.h"
#include "HeapSort.h"

int main(int argc, const char * argv[]) {
    int arr[9] = {25,17,36,2,3,100,1,19,7};
    

    GetHeightSum(arr, 9);


    return 0;
}
