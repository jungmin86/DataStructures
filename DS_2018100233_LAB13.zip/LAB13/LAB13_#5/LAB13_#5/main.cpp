#include <iostream>
#include "Student.h"
#include "HeapSort.h"

using namespace std;

int main() {

    int arr[9] = {25, 17, 36, 2, 3, 100, 1, 19, 7};
    HeapSort(arr, 9);
}
